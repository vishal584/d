package com.example.moviecatalougeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieCatalougeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
